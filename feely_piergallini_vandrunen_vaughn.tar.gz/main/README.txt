Language & Statistics
Final Project
4/28/13
Weston Feely, Mario Piergallini, Tom van Drunen, Callie Vaughn

Usage:
./RunMe.sh <test_data> <test_data_labels>
