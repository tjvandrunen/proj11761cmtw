Language & Statistics
Final Project
4/28/13
Weston Feely, Mario Piergallini, Tom van Drunen, Callie Vaughn

Usage:
./RunMe.sh <test_data> <test_data_labels>

Test data should be the data to classify.
Test data labels can be the labels for this file, or a dummy file containing a column of all zeros which is the same length as the test data.
